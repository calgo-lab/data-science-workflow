from __future__ import annotations

import numpy as np


def random_email() -> dict[str, str]:
    return {
        "subject": str(np.random.choice(["Urgent invoice update", "Meeting reminder", "Free gift card inside", "Account verification needed"])),
        "body": str(np.random.choice(["Please review the attached note.", "Click now to claim your prize.", "Open attachment for details.", "See details at your convenience."]))
    }


def model_predict(email: dict[str, str], spam_probability: float) -> str:
    np.random.seed(hash(email.__str__()) % (2**8))
    return np.random.choice(["Spam", "Not spam"], p=[spam_probability, 1 - spam_probability])
