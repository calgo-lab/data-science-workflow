from __future__ import annotations

import os
import sys
from pathlib import Path

import requests
import streamlit as st

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from shared.mock_model import random_email

BACKEND_URL = os.getenv("BACKEND_URL", "http://localhost:8008")

st.set_page_config(page_title="DSW Spam Demo", page_icon="📧")
st.title("DSW Spam Detection Demo")
st.write("A tiny example for showing a spam classifier workflow. Uses deterministic random predictions to simulate a model.")

if "email" not in st.session_state:
    st.session_state.email = random_email()

if st.button("Generate random email"):
    st.session_state.email = random_email()
    st.rerun()

st.subheader("Message")
title = st.text_input("Title", value=st.session_state.email["subject"])
body = st.text_area("Body", value=st.session_state.email["body"])
spam_probability = st.slider("Spam probability", 0.0, 1.0, 0.5, 0.05)

if st.button("Predict"):
    st.session_state.email = {"subject": title, "body": body}
    try:
        response = requests.post(
            f"{BACKEND_URL}/predict",
            json={"subject": title, "body": body, "spam_probability": spam_probability},
            timeout=5,
        )
        response.raise_for_status()
        result = response.json()
        prediction = result["prediction"]
        
        if prediction == "Spam":
            st.error(f"Prediction: {prediction}")
        else:
            st.success(f"Prediction: {prediction}")
    except requests.RequestException as exc:
        st.error(f"Backend request failed: {exc}")
