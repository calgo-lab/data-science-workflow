from __future__ import annotations

import sys
from pathlib import Path

from fastapi import FastAPI
from pydantic import BaseModel

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from shared.mock_model import model_predict

app = FastAPI(title="Spam Demo API", version="0.1.0")


class PredictRequest(BaseModel):
    subject: str
    body: str
    spam_probability: float


@app.post("/predict")
def predict(request: PredictRequest) -> dict[str, str]:
    email = {"subject": request.subject, "body": request.body}
    prediction = model_predict(email, request.spam_probability)
    return {"prediction": prediction}
